package com.example.hp.helpers;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Main15Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main15);
    }
}
